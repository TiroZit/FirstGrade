﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ProjectMonoGame01.Controllers
{
    public class MouseController : ControllerBase
    {
        public override void Update()
        {
            if (slave == null) return;

            MouseState ms = Mouse.GetState();
            slave.SetPosition(ms.X, ms.Y);

            base.Update();
        }
    }
}
