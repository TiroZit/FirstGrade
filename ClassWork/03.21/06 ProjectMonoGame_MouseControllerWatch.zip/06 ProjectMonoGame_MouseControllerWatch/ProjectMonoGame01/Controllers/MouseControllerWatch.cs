﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace ProjectMonoGame01.Controllers
{
    public class MouseControllerWatch :
        ControllerBase
    {
        public override void Update()
        {
            if (slave == null) return;

            MouseState ms = Mouse.GetState();

            Vector2 v1 = slave.Position;
            Vector2 v2 = new Vector2(ms.X, ms.Y);
            Vector2 v3 = v2 - v1;

            double alpha = Math.Atan2(v3.Y, v3.X);
            slave.Angle = (float) alpha;

            base.Update();
        }
    }
}
